# 差异

1. 默认身份认证过程由“Http Basic认证”变更为“表单认证”。
2. 配置项统一加入了“spring”前缀，例如“security.user.name”，在新版中变更为“spring.security.user.name”。
